﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Test
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtusername = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtans = New System.Windows.Forms.TextBox()
        Me.txta = New System.Windows.Forms.TextBox()
        Me.txtb = New System.Windows.Forms.TextBox()
        Me.txtc = New System.Windows.Forms.TextBox()
        Me.txtd = New System.Windows.Forms.TextBox()
        Me.txtquestion = New System.Windows.Forms.TextBox()
        Me.txtqno = New System.Windows.Forms.TextBox()
        Me.MetroTile7 = New MetroFramework.Controls.MetroTile()
        Me.MetroTile6 = New MetroFramework.Controls.MetroTile()
        Me.MetroTile5 = New MetroFramework.Controls.MetroTile()
        Me.MetroTile4 = New MetroFramework.Controls.MetroTile()
        Me.MetroTile3 = New MetroFramework.Controls.MetroTile()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtusername
        '
        Me.txtusername.Enabled = False
        Me.txtusername.Location = New System.Drawing.Point(50, 63)
        Me.txtusername.Name = "txtusername"
        Me.txtusername.Size = New System.Drawing.Size(114, 20)
        Me.txtusername.TabIndex = 29
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(339, 366)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(90, 30)
        Me.Button1.TabIndex = 28
        Me.Button1.Text = "NEXT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtans
        '
        Me.txtans.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtans.Location = New System.Drawing.Point(206, 320)
        Me.txtans.Name = "txtans"
        Me.txtans.Size = New System.Drawing.Size(173, 26)
        Me.txtans.TabIndex = 26
        '
        'txta
        '
        Me.txta.Enabled = False
        Me.txta.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txta.Location = New System.Drawing.Point(95, 220)
        Me.txta.Name = "txta"
        Me.txta.Size = New System.Drawing.Size(206, 26)
        Me.txta.TabIndex = 21
        '
        'txtb
        '
        Me.txtb.Enabled = False
        Me.txtb.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtb.Location = New System.Drawing.Point(355, 220)
        Me.txtb.Name = "txtb"
        Me.txtb.Size = New System.Drawing.Size(191, 26)
        Me.txtb.TabIndex = 20
        '
        'txtc
        '
        Me.txtc.Enabled = False
        Me.txtc.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtc.Location = New System.Drawing.Point(95, 268)
        Me.txtc.Name = "txtc"
        Me.txtc.Size = New System.Drawing.Size(206, 26)
        Me.txtc.TabIndex = 19
        '
        'txtd
        '
        Me.txtd.Enabled = False
        Me.txtd.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtd.Location = New System.Drawing.Point(355, 268)
        Me.txtd.Name = "txtd"
        Me.txtd.Size = New System.Drawing.Size(191, 26)
        Me.txtd.TabIndex = 18
        '
        'txtquestion
        '
        Me.txtquestion.Enabled = False
        Me.txtquestion.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtquestion.Location = New System.Drawing.Point(49, 138)
        Me.txtquestion.Multiline = True
        Me.txtquestion.Name = "txtquestion"
        Me.txtquestion.Size = New System.Drawing.Size(497, 59)
        Me.txtquestion.TabIndex = 17
        '
        'txtqno
        '
        Me.txtqno.Enabled = False
        Me.txtqno.Location = New System.Drawing.Point(50, 103)
        Me.txtqno.Name = "txtqno"
        Me.txtqno.Size = New System.Drawing.Size(100, 20)
        Me.txtqno.TabIndex = 16
        Me.txtqno.Visible = False
        '
        'MetroTile7
        '
        Me.MetroTile7.ActiveControl = Nothing
        Me.MetroTile7.Location = New System.Drawing.Point(95, 320)
        Me.MetroTile7.Name = "MetroTile7"
        Me.MetroTile7.Size = New System.Drawing.Size(103, 23)
        Me.MetroTile7.TabIndex = 35
        Me.MetroTile7.Text = "Answer:"
        Me.MetroTile7.UseSelectable = True
        '
        'MetroTile6
        '
        Me.MetroTile6.ActiveControl = Nothing
        Me.MetroTile6.Location = New System.Drawing.Point(308, 268)
        Me.MetroTile6.Name = "MetroTile6"
        Me.MetroTile6.Size = New System.Drawing.Size(27, 23)
        Me.MetroTile6.TabIndex = 34
        Me.MetroTile6.Text = "D:"
        Me.MetroTile6.UseSelectable = True
        '
        'MetroTile5
        '
        Me.MetroTile5.ActiveControl = Nothing
        Me.MetroTile5.Location = New System.Drawing.Point(49, 268)
        Me.MetroTile5.Name = "MetroTile5"
        Me.MetroTile5.Size = New System.Drawing.Size(29, 23)
        Me.MetroTile5.TabIndex = 33
        Me.MetroTile5.Text = "C:"
        Me.MetroTile5.UseSelectable = True
        '
        'MetroTile4
        '
        Me.MetroTile4.ActiveControl = Nothing
        Me.MetroTile4.Location = New System.Drawing.Point(307, 223)
        Me.MetroTile4.Name = "MetroTile4"
        Me.MetroTile4.Size = New System.Drawing.Size(28, 23)
        Me.MetroTile4.TabIndex = 32
        Me.MetroTile4.Text = "B:"
        Me.MetroTile4.UseSelectable = True
        '
        'MetroTile3
        '
        Me.MetroTile3.ActiveControl = Nothing
        Me.MetroTile3.Location = New System.Drawing.Point(50, 223)
        Me.MetroTile3.Name = "MetroTile3"
        Me.MetroTile3.Size = New System.Drawing.Size(28, 23)
        Me.MetroTile3.TabIndex = 31
        Me.MetroTile3.Text = "A:"
        Me.MetroTile3.UseSelectable = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(456, 366)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(90, 30)
        Me.Button2.TabIndex = 36
        Me.Button2.Text = "Finish"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Test
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(592, 430)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.MetroTile7)
        Me.Controls.Add(Me.MetroTile6)
        Me.Controls.Add(Me.MetroTile5)
        Me.Controls.Add(Me.MetroTile4)
        Me.Controls.Add(Me.MetroTile3)
        Me.Controls.Add(Me.txtusername)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtans)
        Me.Controls.Add(Me.txta)
        Me.Controls.Add(Me.txtb)
        Me.Controls.Add(Me.txtc)
        Me.Controls.Add(Me.txtd)
        Me.Controls.Add(Me.txtquestion)
        Me.Controls.Add(Me.txtqno)
        Me.Name = "Test"
        Me.Text = "Test"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtusername As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtans As System.Windows.Forms.TextBox
    Friend WithEvents txta As System.Windows.Forms.TextBox
    Friend WithEvents txtb As System.Windows.Forms.TextBox
    Friend WithEvents txtc As System.Windows.Forms.TextBox
    Friend WithEvents txtd As System.Windows.Forms.TextBox
    Friend WithEvents txtquestion As System.Windows.Forms.TextBox
    Friend WithEvents txtqno As System.Windows.Forms.TextBox
    Friend WithEvents MetroTile7 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile6 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile5 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile4 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile3 As MetroFramework.Controls.MetroTile
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
